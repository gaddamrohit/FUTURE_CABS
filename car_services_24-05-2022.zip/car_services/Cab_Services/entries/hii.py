class Cab:
    def main(self):
        print("""     
                       _______
                      //  ||\ \\
                _____//___||_\ \___
                )  _          _    \\
                |_/ \________/ \___|
               ___\_/________\_/______
        """)
 
print("\n\t-------WELCOME TO CAR SERVICE!-------\n")
a=Cab()
a.main()